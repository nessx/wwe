<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, user-scalable=no, initial-scale=1.0, maximum-scale=1.0, minimum-scale=1.0">
<link rel="stylesheet" href="./css/bootstrap.css"> 
<link rel="stylesheet" href="./css/style.css">  
<link rel="stylesheet" href="./css/animate.css">
<link rel="stylesheet" href="./css/MediaQueries.css">
<link rel="stylesheet" href="./css/font-awesome.min.css">
<link rel="stylesheet" rel="stylesheet" href="./css/ui-lightness/jquery-ui-1.10.4.custom.min.css">      
<script src="./js/jquery-2.1.0.min.js"></script>
<script src="./js/bootstrap.js"></script>
<script src="./js/jquery-ui-1.10.4.custom.min.js"></script>