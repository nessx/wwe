<footer>
  <div class="container">
    <div class="row">
      <div class="col-sm-4">
        <h4 class="text-info">info</h4>
        <p class="text-warning"> 
        Telefono: 66666666<br>
        E-mail: <a href="#">admin@example.com</a>
        </p>
      </div>
      <div class="col-sm-4">
      </div>
    </div>
    <h4 class="text-center" style="color: #FFF;">ticketing © 2020</h4>
  </div>
</footer>